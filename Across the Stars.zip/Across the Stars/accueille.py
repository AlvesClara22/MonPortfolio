import pygame
import time
pygame.init()



#nom du jeu
pygame.display.set_caption("Across The Stars")
#resolution (720p)
screen = pygame.display.set_mode(((1280),720))
#arriere plan du jeu
background = pygame.image.load('image_accueil/espace.jpg')
# Cadre = pygame.image.load('image_accueille/cadre_clair(1).png')
# Cadre_play = pygame.image.load('image_accueille/cadre_clair_play (5).png')
# Cadre_exit = pygame.image.load('image_accueille/cadre_clair_exit (2).png')
Logo = pygame.image.load('image_accueil/logooo (3).png')
Play = pygame.image.load('image_accueil/Play.png').convert_alpha()
Exit = pygame.image.load('image_accueil/exit.png').convert_alpha()
bouton_play = Play.get_rect()
bouton_exit = Exit.get_rect()


#ouvrir et fermer le jeu 
running = True







while running:
    #appliquer l'arriere plan de l'écran d'accueille
    screen.blit(background,(0,0)) 
    #appliquer le logo
    screen.blit(Logo,(392,55))
    #appliquer l'image du bouton play
    screen.blit(Play,(330,455))
    #appliquer l'image du bouton exit
    screen.blit(Exit,(700,447))


  
    #si la sourie est sur la fenêtre
    if pygame.mouse.get_focused():
        #Trouve position de la souris
        x, y = pygame.mouse.get_pos()
        ## S'il y a collision:

        if x < 700+263 and x > 700 and y < 447+160 and y > 447 :
            pressed = pygame.mouse.get_pressed()
            if pressed[0]: # 0=gauche, 1=milieu, 2=droite
                running = False
        
        if x < 330+273 and x > 330 and y < 455+141 and y > 455 :
            pressed = pygame.mouse.get_pressed()
            #si on clique sur play on ouvre le jeu
            if pressed[0]: # 0=gauche, 1=milieu, 2=droite
                import MAIN
                
                
                

    
    #si le joueur ferme la fenetre
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
            
    #mettre a jour l'ecran
    pygame.display.flip()





pygame.quit()
















