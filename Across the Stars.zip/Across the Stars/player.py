# Créé par jade.defaria, le 19/12/2023 en Python 3.7
import pygame
class Vaisseau:
    def __init__(self,x=10,y=10):
        self.image = pygame.image.load('images/LE VAISSEAU.png')
        self.tir = pygame.image.load('images/GRIIIIIIPWAPWAPUUUWUWUWUWU.png')
        self.rect = self.image.get_rect()
        self.rect2 = self.tir.get_rect()
        self.posx = x
        self.posy = y
        self.posxtir = 0
        self.posytir = 0
        self.health = 3
        self.max_health = 3
        self.attack = 50
        self.velocity = 5
        self.liste_tir = []
        self.nb_tir = 0
        self.move = 1
       


    def deplacement(self):
        if self.move == 1 :
            keys = pygame.key.get_pressed()                 #prise en compte des événements clavier                   
            if keys[pygame.K_z] and self.posy > 0:        #si touche "z" pressée
                print("z")
                self.posy -= 10                             #monter le vaisseau de 20
            if keys[pygame.K_s] and self.posy < 620:           #si touche "s" pressée
                self.posy += 10              #baisser le vaisseau de 20
                print("s")
            if keys[pygame.K_q] and self.posx > 0:           
                self.posx -= 10             
                print("q")
            if keys[pygame.K_d] and self.posx < 1100:           
                self.posx += 10              
                print("d")
                    
            
    def init_tir (self):                 #variable qui prend en compte la largeur de l'écran
        if self.move == 1 :
            self.nb_tir = len(self.liste_tir)
            self.posxtir = self.posx + 30
            self.posytir = self.posy + 17
            tir = [self.posxtir, self.posytir]
            if self.nb_tir < 10:
                self.liste_tir.append(tir)
            
        
    def mvt_tir(self):
        if self.move == 1 :
            self.posxtir += 7
            for i in range(len(self.liste_tir)):
                self.liste_tir[i][0] += 25
            if self.liste_tir[0][0] >= 1280:
                self.liste_tir.pop(0)
                self.nb_tir = len(self.liste_tir)