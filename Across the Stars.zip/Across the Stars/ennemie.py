# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 13:34:10 2024

@author: alexis.dandre
"""

import pygame
import random

class Ennemie:
    
    def __init__ (self,x=1100,y=300):
        self.image = pygame.image.load('images/mechant.png')
        self.tir = pygame.image.load('images/tir_ennemie_v2.png')
        self.rect = self.image.get_rect()
        self.rect2 = self.tir.get_rect()
        self.posx = x
        self.posy = y
        self.posxtir = 0
        self.posytir = 0
        self.attack = 10
        self.velocity = 5
        self.health = 20
        self.liste_ennemie = [[self.posx,self.posy,self.health]]
        self.liste_tir1 = []
        self.nb_tir = 0
        self.moove_act = False
        self.actif = True
        self.score = 0
        self.move = 1
        
    
    def nv_ennemie(self):
        if self.move == 1 :
            nvennemie = [self.posx,self.posy,self.health]
            self.liste_ennemie.append(nvennemie)
            #self.score +=10
          
            
    def deplacement(self):
        if self.move == 1 :
            #if self.moove_act == False:
            for j in range(len(self.liste_ennemie)):
                i = random.randint(1,4)
                vit = 20
                if i == 1 and self.liste_ennemie[j][1] > 0:
                    print("monte")
                    self.liste_ennemie[j][1] -= vit
                    self.moove_act = True
                if i == 2 and self.liste_ennemie[j][1] < 620:
                    print("descend")
                    self.liste_ennemie[j][1] += vit
                    self.moove_act = True
                if i == 3 and self.liste_ennemie[j][0] > 0:
                    print("va a gauche")
                    self.liste_ennemie[j][0] -= vit
                    self.moove_act = True
                if i == 4 and self.liste_ennemie[j][0] < 1100:
                    print("va a droite")
                    self.liste_ennemie[j][0] += vit
                    self.moove_act = True
                
        
          
                  
    def init_tir (self):
        if self.move == 1 :
            for m in range(len(self.liste_ennemie)):  
                self.nb_tir = len(self.liste_tir1)
                self.posxtir = self.liste_ennemie[m][0] + 30
                self.posytir = self.liste_ennemie[m][1] + 15
                tir = [self.posxtir, self.posytir]
                if self.nb_tir < 10:
                    self.liste_tir1.append(tir)
            
        
    def mvt_tir(self):
        if self.move == 1 :
            self.posxtir += 7
            for i in range(len(self.liste_tir1)):
                self.liste_tir1[i][0] -= 12
            if self.liste_tir1[0][0] <= 0:
                self.liste_tir1.pop(0)
                self.nb_tir = len(self.liste_tir1)
                
    def mort(self):
        if self.move == 1 :
            if self.health <=0 :
                del(self)
                self.actif = False