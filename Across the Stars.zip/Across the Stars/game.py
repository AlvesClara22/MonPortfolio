# Créé par jade.defaria, le 19/12/2023 en Python 3.7
import pygame
from player import Vaisseau

class Game:

    def __init__(self):
        self.player = Vaisseau()


