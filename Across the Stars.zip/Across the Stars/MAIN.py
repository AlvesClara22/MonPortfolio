# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
                                                        #setup de l'affichage du jeu
import pygame, sys
import math
import time
import threading
from game import Game
from player import Vaisseau
from pygame.locals import *
from ennemie import Ennemie
from Boss import Boss
timer = pygame.time.Clock()
timer1 = pygame.time.get_ticks()
pygame.init()

fps=60

WIDTH = 1280
HEIGHT = 720


#generer fenetre du jeu
screen = pygame.display.set_mode([WIDTH, HEIGHT])
pygame.display.set_caption('Across The Stars')
Vaisseau0 = Vaisseau(0,300)
Ennemie0 = Ennemie()
Boss0 = Boss()





#arriere plan du jeu
background = pygame.image.load('image_accueil\desktop-wallpaper-pixel-space.jpg')
background_width = background.get_width()
background = pygame.transform.scale(background, (background_width, HEIGHT))
background_rect = background.get_rect()

scroll = 0
panels = math.ceil(WIDTH / background_width) + 2


#pygame.display.flip()

#charger notre jeu
game = Game()

#ouvrir et fermer le jeu
running = True
running = True
tir_en_cours = False
wait_next = -1
tick_ennemie=0
tir_ennemie = 0
tir_boss = 0
nb_ennemie = 0
nb_mort = 0 
play = True
timer_end = 1



while running:
    tick_ennemie+=1
    print(tick_ennemie)
    if tick_ennemie == 7:
        tick_ennemie=0
        Ennemie0.deplacement()
        Boss0.deplacement()
                

    timer.tick(fps)
    
    
    

    

    #affichage du vaisseau, de l'ennemie et du fond déroulant
    for i in range(panels):
        screen.blit(background, (i * background_width + scroll - background_width, 0))
        screen.blit(Vaisseau0.image, (Vaisseau0.posx,Vaisseau0.posy))
        for j in range(len(Ennemie0.liste_ennemie)):
            screen.blit(Ennemie0.image, (Ennemie0.liste_ennemie[j][0],Ennemie0.liste_ennemie[j][1]))
        for p in range(len(Boss0.liste_boss)):
            screen.blit(Boss0.image, (Boss0.liste_boss[p][0],Boss0.liste_boss[p][1]))
        
    # affichage d'un chronomètre
    current_time = (pygame.time.get_ticks() - timer1)/1000
    font = pygame.font.Font("Police/space age.ttf", 60)
    afficher = font.render("Timer: " + str(current_time), 1, (255, 255, 255))
    if play == True:
        screen.blit(afficher, (20,30))
        print(current_time)
    
    #affichage du score
    score = Ennemie0.score
    font = pygame.font.Font("Police/space age.ttf", 60)
    aff = font.render("Score: " + str(score), 1, (255, 255, 255))
    screen.blit(aff, (20,80))
    print(score)
    
    if play == False :
        #arreter les mouvements vaisseau
        Vaisseau0.move = Vaisseau0.move -1
        #arreter les mouvements ennemis
        Ennemie0.move = Ennemie0.move -1
        #arreter les tirs du vaisseau
        if len(Vaisseau0.liste_tir)>0 :
            Vaisseau0.liste_tir.pop(0)
        #arreter les tirs ennemis
        if len(Ennemie0.liste_tir1)>0 :
            Ennemie0.liste_tir1.pop(0)
        #arreter le timer
        if timer_end == 1 :
            score_timer = current_time
            timer_end = 0
        font = pygame.font.Font("Police/space age.ttf", 60)
        afficher = font.render("Timer: " + str(score_timer), 1, (255, 255, 255))
        screen.blit(afficher, (20,30))
        #arreter les mouvements du boss
        Boss0.move = Boss0.move -1
        #arreter les tirs du boss
        if len(Boss0.liste_tir1)>0 :
            Boss0.liste_tir1.pop(0)
        #afficher le game over
        screen.blit(pygame.image.load('images/GAME_OVER.png'), (280,150))



    
    
    scroll -= 3
    if abs(scroll)> background_width:
        scroll = 0

    #Boucle événemetielle
    #Boucle tir du vaisseau
    for event in pygame.event.get():
        if event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
            tir_en_cours = True
            print("tir")
            Vaisseau0.init_tir()
        #si le joueur ferme la fenetre
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
    
    #gestion du mouvement des tirs du joueur
    if len(Vaisseau0.liste_tir) > 0 :
        Vaisseau0.mvt_tir()
        for tir in Vaisseau0.liste_tir:
            screen.blit(Vaisseau0.tir, (tir[0],tir[1]))
            
    if Vaisseau0.health == 3 :
        screen.blit(pygame.image.load('images/Vaisseau Vie (1).png'), (1190,30))
        screen.blit(pygame.image.load('images/Vaisseau Vie (1).png'), (1130,30))
        screen.blit(pygame.image.load('images/Vaisseau Vie (1).png'), (1070,30))
    elif Vaisseau0.health ==2 :
        screen.blit(pygame.image.load('images/Vaisseau Vie (1).png'), (1190,30))
        screen.blit(pygame.image.load('images/Vaisseau Vie (1).png'), (1130,30))
    elif Vaisseau0.health ==1 :
        screen.blit(pygame.image.load('images/Vaisseau Vie (1).png'), (1190,30))
            
            
    #Boucle tir ennemie        
    tir_ennemie+=1
    print(tir_ennemie)
    if tir_ennemie == 30 :
        tir_ennemie=0
        print("tir")
        Ennemie0.init_tir()
        

    #gestion du mouvement des tirs des ennemis
    if len(Ennemie0.liste_tir1) > 0 :
        Ennemie0.mvt_tir()
        for tir in Ennemie0.liste_tir1:
            screen.blit(Ennemie0.tir, (tir[0],tir[1]))
            
    
    #Boucle tir Boss        
    tir_boss+=1
    print(tir_ennemie)
    if tir_boss == 30 :
        tir_boss=0
        print("tir")
        Boss0.init_tir()
        

    #gestion du mouvement des tirs des Boss
    if len(Boss0.liste_tir1) > 0 :
        Boss0.mvt_tir()
        for tir in Boss0.liste_tir1:
            screen.blit(Boss0.tir, (tir[0],tir[1]))
            
    #Gestion des colisions entre les tirs des ennemis et le vaisseau     
    k = 0
    for i in range (len(Ennemie0.liste_tir1)) :
        EnnemiePosx = Ennemie0.liste_tir1[i-k][0]
        EnnemiePosy = Ennemie0.liste_tir1[i-k][1]
        if Vaisseau0.posx < EnnemiePosx < Vaisseau0.posx + 75 :
            if Vaisseau0.posy - 50 < EnnemiePosy < Vaisseau0.posy + 86 :
                print ("BOOM")
                Ennemie0.liste_tir1.pop(i-k)
                k = k + 1
                if Vaisseau0.health != 0 :
                    Vaisseau0.health = Vaisseau0.health - 1
                if Vaisseau0.health <= 0 :
                    print ("Vous êtes mort.")
                    play = False
    
    
    
    #Gestion des colisions entre les tirs du joueur et l'ennemis
    h = 0
    for j in range (len(Vaisseau0.liste_tir)) :
        VaisseauPosx = Vaisseau0.liste_tir[j-h][0]
        VaisseauPosy = Vaisseau0.liste_tir[j-h][1]
        for o in range(len(Ennemie0.liste_ennemie)):
            if Ennemie0.liste_ennemie[o][0] < VaisseauPosx < Ennemie0.liste_ennemie[o][0] + 132 :
                if Ennemie0.liste_ennemie[o][1] < VaisseauPosy < Ennemie0.liste_ennemie[o][1] + 87 :
                    print ("piw")
                    Vaisseau0.liste_tir.pop(j-h)
                    h = h + 1
                    if Ennemie0.liste_ennemie[o][2] != 0 :
                        Ennemie0.liste_ennemie[o][2] = Ennemie0.liste_ennemie[o][2] - 5
                    if Ennemie0.liste_ennemie[o][2] <= 0 :
                        print ("Ennemie mort.")
                        Ennemie0.liste_ennemie.pop(o)
                        Ennemie0.score +=10
                        nb_ennemie += 1
                        wait_next = current_time + 2
                        
    u = 0
    for i in range (len(Boss0.liste_tir1)) :
        EnnemiePosx = Boss0.liste_tir1[i-u][0]
        EnnemiePosy = Boss0.liste_tir1[i-u][1]
        if Vaisseau0.posx < EnnemiePosx < Vaisseau0.posx + 75 :
            if Vaisseau0.posy - 50 < EnnemiePosy < Vaisseau0.posy + 86 :
                print ("BOOM")
                Boss0.liste_tir1.pop(i-k)
                u = u + 1
                if Vaisseau0.health != 0 :
                    Vaisseau0.health = Vaisseau0.health - 2
                if Vaisseau0.health <= 0 :
                    print ("Vous êtes mort.")
                    play = False
    
    
    
    #Gestion des colisions entre les tirs du joueur et le boss 
    y = 0
    for j in range (len(Vaisseau0.liste_tir)) :
        VaisseauPosx = Vaisseau0.liste_tir[j-y][0]
        VaisseauPosy = Vaisseau0.liste_tir[j-y][1]
        for o in range(len(Boss0.liste_boss)):
            if Boss0.liste_boss[o][0] < VaisseauPosx < Boss0.liste_boss[o][0] + 132 :
                if Boss0.liste_boss[o][1] < VaisseauPosy < Boss0.liste_boss[o][1] + 130 :
                    print ("piw")
                    Vaisseau0.liste_tir.pop(j-h)
                    y = y + 1
                    if Boss0.liste_boss[o][2] != 0 :
                        Boss0.liste_boss[o][2] = Boss0.liste_boss[o][2] - 5
                    if Boss0.liste_boss[o][2] <= 0 :
                        print ("Ennemie mort.")
                        Boss0.liste_boss.pop(o)
                        Boss0.score +=10
                        nb_ennemie += 1
                        wait_next = current_time + 2
    
    #apparition d'un nouvel ennemi                    
    if nb_ennemie < 5:
        if current_time > wait_next and len(Ennemie0.liste_ennemie)==0:
            Ennemie0.nv_ennemie()
            wait_next = -1
    
    #apparition du boss
    if Ennemie0.score == 10 and len(Boss0.liste_boss) == 0:
        Boss0.nv_boss()
            
    


   #mettre a jour l'ecran
    pygame.display.flip()

    Vaisseau0.deplacement()
    
    






