# -*- coding: utf-8 -*-
"""
Created on Tue Mar 19 13:43:00 2024

@author: alexis.dandre
"""

import pygame
import random

class Boss:
    
    def __init__ (self,x=900,y=300):
        self.image = pygame.image.load('images/BOSS.png')
        self.tir = pygame.image.load('images/tirBOSS.png')
        self.rect = self.image.get_rect()
        self.rect2 = self.tir.get_rect()
        self.posx = x
        self.posy = y
        self.posxtir = 0
        self.posytir = 0
        self.health = 100
        self.liste_boss = []        #gestion des ennemies sous forme d'une liste de listes
        self.liste_tir1 = []
        self.nb_tir = 0
        self.score = 0
        self.move = 1
        
        
    def nv_boss(self):
        if self.move == 1 :
            nvboss = [self.posx,self.posy,self.health]                   #création d'un nouvel ennemi dans la liste
            self.liste_boss.append(nvboss)
      
        
    def deplacement(self):
        if self.move == 1 :
            for j in range(len(self.liste_boss)):                        #gestion des mouvements de facon aléatoire
                i = random.randint(1,4)
                vit = 20
                if i == 1 and self.liste_boss[j][1] > 0:
                    print("monte")
                    self.liste_boss[j][1] -= vit
                    self.moove_act = True
                if i == 2 and self.liste_boss[j][1] < 620:
                    print("descend")
                    self.liste_boss[j][1] += vit
                    self.moove_act = True
                if i == 3 and self.liste_boss[j][0] > 0:
                    print("va a gauche")
                    self.liste_boss[j][0] -= vit
                    self.moove_act = True
                if i == 4 and self.liste_boss[j][0] < 1100:
                    print("va a droite")
                    self.liste_boss[j][0] += vit
                    self.moove_act = True
            
    
      
              
    def init_tir (self):
        if self.move == 1 :
            for m in range(len(self.liste_boss)):  
                self.nb_tir = len(self.liste_tir1)
                self.posxtir = self.liste_boss[m][0] - 20               #calibrage du tir par rapport a l'ennemie
                self.posytir = self.liste_boss[m][1] + 120                #calibrage du tir par rapport a l'ennemie
                tir = [self.posxtir, self.posytir]
                if self.nb_tir < 10:                                        #limite de 10 tirs par ennemi
                    self.liste_tir1.append(tir)
        
    
    def mvt_tir(self):
        if self.move == 1 :                                                #gestion du mouvement des tirs de chaque ennemi
            self.posxtir += 7
            for i in range(len(self.liste_tir1)):
                self.liste_tir1[i][0] -= 12
            if self.liste_tir1[0][0] <= 0:                                  #si le tir sort de l'écran, on l'enlève de la liste
                self.liste_tir1.pop(0)
                self.nb_tir = len(self.liste_tir1)